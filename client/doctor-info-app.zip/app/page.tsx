"use client"

import { useState, useEffect, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  User,
  MapPin,
  Phone,
  GraduationCap,
  Building2,
  Shield,
  Calendar,
  Search,
  Star,
  CheckCircle,
  AlertCircle,
  XCircle,
  Activity,
} from "lucide-react"
import { Pagination } from "@/components/pagination"
import { LoadingSkeleton } from "@/components/loading-skeleton"
import { Filters } from "@/components/filters"
import type { Doctor, ApiResponse } from "@/types/doctor"
import { ApiStatus } from "@/components/api-status"

export default function DoctorInfoApp() {
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [filters, setFilters] = useState({ state: "", city: "" })
  const [currentPage, setCurrentPage] = useState(1)
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    totalDoctors: 0,
    hasNextPage: false,
    hasPrevPage: false,
    pageSize: 12,
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [totalCount, setTotalCount] = useState<number | null>(null)

  const fetchDoctors = useCallback(
    async (page: number, search: string, filterParams: { state: string; city: string }) => {
      setLoading(true)
      setError(null)

      try {
        const params = new URLSearchParams({
          page: page.toString(),
          limit: "12",
        })

        if (search) {
          params.append("search", search)
        }
        if (filterParams.state) {
          params.append("state", filterParams.state)
        }
        if (filterParams.city) {
          params.append("city", filterParams.city)
        }

        const response = await fetch(`/api/doctors?${params}`)

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.message || "Failed to fetch doctors")
        }

        const data: ApiResponse = await response.json()
        setDoctors(data.doctors)
        setPagination(data.pagination)
      } catch (err) {
        setError(err instanceof Error ? err.message : "An error occurred")
        setDoctors([])
      } finally {
        setLoading(false)
      }
    },
    [],
  )

  const fetchTotalCount = useCallback(async () => {
    try {
      const response = await fetch("/api/doctors/count")
      if (response.ok) {
        const data = await response.json()
        setTotalCount(data.count || data.total_count || null)
      }
    } catch (err) {
      console.error("Failed to fetch total count:", err)
    }
  }, [])

  useEffect(() => {
    fetchDoctors(currentPage, searchTerm, filters)
  }, [currentPage, searchTerm, filters, fetchDoctors])

  useEffect(() => {
    fetchTotalCount()
  }, [fetchTotalCount])

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const handleSearch = (value: string) => {
    setSearchTerm(value)
    setCurrentPage(1)
  }

  const handleFilterChange = (newFilters: { state: string; city: string }) => {
    setFilters(newFilters)
    setCurrentPage(1)
  }

  const formatPhone = (phone: number | null) => {
    if (!phone) return "N/A"
    const phoneStr = phone.toString()
    if (phoneStr.length === 10) {
      return `(${phoneStr.slice(0, 3)}) ${phoneStr.slice(3, 6)}-${phoneStr.slice(6)}`
    }
    return phoneStr
  }

  const formatAddress = (address: any) => {
    if (!address) return "N/A"
    const parts = []
    if (address.line_1) parts.push(address.line_1)
    if (address.line_2) parts.push(address.line_2)
    if (address.city) parts.push(address.city)
    if (address.state) parts.push(address.state)
    if (address.zip_code) parts.push(address.zip_code.toString())
    return parts.join(", ") || "N/A"
  }

  const getDisplayAddress = (doctor: Doctor) => {
    // Приоритет: practice_location, затем mailing_address
    const practiceLocation = doctor.business_addresses?.practice_location?.practice_location
    const mailingAddress = doctor.business_addresses?.mailing_address?.mailing_address
    return practiceLocation || mailingAddress
  }

  const getDisplayPhone = (doctor: Doctor) => {
    const practiceLocation = doctor.business_addresses?.practice_location?.practice_location
    const mailingAddress = doctor.business_addresses?.mailing_address?.mailing_address
    return practiceLocation?.phone || mailingAddress?.phone
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
        <div className="max-w-4xl mx-auto px-6 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-white/60 backdrop-blur-sm border-white/20 shadow-xl">
              <CardContent className="flex flex-col items-center space-y-4 p-6">
                <AlertCircle className="w-12 h-12 text-red-500" />
                <h2 className="text-xl font-semibold text-gray-900">Ошибка загрузки данных</h2>
                <p className="text-gray-600 text-center">{error}</p>
                <Button
                  onClick={() => fetchDoctors(currentPage, searchTerm, filters)}
                  className="bg-gradient-to-r from-blue-600 to-indigo-600"
                >
                  Попробовать снова
                </Button>
              </CardContent>
            </Card>
            <ApiStatus />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-white/20 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                  {"CLAUS DOC"}
                </h1>
                <p className="text-sm text-gray-500">
                  Healthcare Provider Directory
                  {totalCount && <span className="ml-2">• {totalCount.toLocaleString()} провайдеров</span>}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Поиск врачей..."
                  value={searchTerm}
                  onChange={(e) => handleSearch(e.target.value)}
                  className="pl-10 w-80 bg-white/50 border-white/20 focus:bg-white/80 transition-all duration-200"
                />
              </div>
              <Filters onFilterChange={handleFilterChange} currentFilters={filters} />
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {selectedDoctor ? (
          /* Detailed Doctor View */
          <div className="space-y-6">
            <Button variant="ghost" onClick={() => setSelectedDoctor(null)} className="mb-4 hover:bg-white/50">
              ← Назад к каталогу
            </Button>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Main Info Card */}
              <Card className="lg:col-span-2 bg-white/60 backdrop-blur-sm border-white/20 shadow-xl">
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="space-y-2">
                      <CardTitle className="text-3xl font-bold text-gray-900">
                        Dr. {selectedDoctor.provider_personal_info.first_name}{" "}
                        {selectedDoctor.provider_personal_info.last_name}
                      </CardTitle>
                      <div className="flex items-center space-x-3">
                        <Badge variant="secondary" className="bg-blue-100 text-blue-800 border-blue-200">
                          {selectedDoctor.provider_personal_info.credentials}
                        </Badge>
                        {selectedDoctor.provider_status.active ? (
                          <Badge className="bg-green-100 text-green-800 border-green-200">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Активен
                          </Badge>
                        ) : (
                          <Badge variant="destructive" className="bg-red-100 text-red-800 border-red-200">
                            <XCircle className="w-3 h-3 mr-1" />
                            Неактивен
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="text-right text-sm text-gray-500">
                      <p>NPI: {selectedDoctor.provider_identification.npi}</p>
                      {selectedDoctor.provider_identification.pac_id && (
                        <p>PAC ID: {selectedDoctor.provider_identification.pac_id}</p>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      {selectedDoctor.provider_professional_info.primary_specialty && (
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                            <Star className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Основная специальность</p>
                            <p className="font-semibold text-gray-900">
                              {selectedDoctor.provider_professional_info.primary_specialty}
                            </p>
                          </div>
                        </div>
                      )}

                      {selectedDoctor.provider_professional_info.medical_school && (
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-teal-500 rounded-lg flex items-center justify-center">
                            <GraduationCap className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Медицинская школа</p>
                            <p className="font-semibold text-gray-900">
                              {selectedDoctor.provider_professional_info.medical_school}
                            </p>
                            {selectedDoctor.provider_professional_info.graduation_year && (
                              <p className="text-sm text-gray-500">
                                Выпуск {selectedDoctor.provider_professional_info.graduation_year}
                              </p>
                            )}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="space-y-4">
                      {selectedDoctor.provider_licensing.license_number && (
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
                            <Shield className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Лицензия</p>
                            <p className="font-semibold text-gray-900">
                              {selectedDoctor.provider_licensing.license_number}
                            </p>
                            {selectedDoctor.provider_licensing.license_state && (
                              <p className="text-sm text-gray-500">
                                Штат: {selectedDoctor.provider_licensing.license_state}
                              </p>
                            )}
                          </div>
                        </div>
                      )}

                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
                          <Calendar className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Последнее обновление</p>
                          <p className="font-semibold text-gray-900">
                            {new Date(selectedDoctor.meta_info.last_update).toLocaleDateString("ru-RU")}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Contact & Location Card */}
              <Card className="bg-white/60 backdrop-blur-sm border-white/20 shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Building2 className="w-5 h-5" />
                    <span>Контактная информация</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {selectedDoctor.current_practice_info.facility_name && (
                    <div>
                      <p className="text-sm text-gray-500 mb-1">Учреждение</p>
                      <p className="font-semibold text-gray-900">
                        {selectedDoctor.current_practice_info.facility_name}
                      </p>
                    </div>
                  )}

                  <div className="flex items-start space-x-3">
                    <MapPin className="w-5 h-5 text-gray-400 mt-0.5" />
                    <div>
                      <p className="text-sm text-gray-500">Адрес</p>
                      <p className="text-gray-900">{formatAddress(getDisplayAddress(selectedDoctor))}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <Phone className="w-5 h-5 text-gray-400" />
                    <div>
                      <p className="text-sm text-gray-500">Телефон</p>
                      <p className="font-semibold text-gray-900">{formatPhone(getDisplayPhone(selectedDoctor))}</p>
                    </div>
                  </div>

                  {selectedDoctor.telehealth_services.telehealth_eligible && (
                    <div className="flex items-center space-x-3">
                      <Activity className="w-5 h-5 text-green-500" />
                      <div>
                        <p className="text-sm text-gray-500">Телемедицина</p>
                        <p className="font-semibold text-green-700">Доступна</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        ) : (
          /* Doctor Directory Grid */
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <h2 className="text-3xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                Медицинские работники
              </h2>
              {!loading && (
                <p className="text-gray-600">
                  {pagination.totalDoctors} провайдер
                  {pagination.totalDoctors !== 1 ? (pagination.totalDoctors < 5 ? "а" : "ов") : ""} найдено
                  {searchTerm && ` по запросу "${searchTerm}"`}
                  {(filters.state || filters.city) && (
                    <span>
                      {" "}
                      с фильтрами: {filters.state && `штат ${filters.state}`}
                      {filters.state && filters.city && ", "}
                      {filters.city && `город ${filters.city}`}
                    </span>
                  )}
                </p>
              )}
            </div>

            {loading ? (
              <LoadingSkeleton />
            ) : doctors.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="w-12 h-12 text-gray-400" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Провайдеры не найдены</h3>
                <p className="text-gray-600">
                  {searchTerm || filters.state || filters.city
                    ? "Попробуйте изменить параметры поиска или фильтры"
                    : "В настоящее время нет доступных провайдеров"}
                </p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {doctors.map((doctor) => {
                    const displayAddress = getDisplayAddress(doctor)
                    return (
                      <Card
                        key={doctor._id}
                        className="bg-white/60 backdrop-blur-sm border-white/20 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer hover:scale-[1.02] group"
                        onClick={() => setSelectedDoctor(doctor)}
                      >
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <CardTitle className="text-xl group-hover:text-blue-600 transition-colors">
                                Dr. {doctor.provider_personal_info.first_name} {doctor.provider_personal_info.last_name}
                              </CardTitle>
                              <Badge variant="outline" className="text-xs">
                                {doctor.provider_personal_info.credentials}
                              </Badge>
                            </div>
                            {doctor.provider_status.active ? (
                              <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                            ) : (
                              <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                            )}
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          {doctor.provider_professional_info.primary_specialty && (
                            <div className="flex items-center space-x-2">
                              <Star className="w-4 h-4 text-purple-500" />
                              <span className="text-sm font-medium text-gray-700">
                                {doctor.provider_professional_info.primary_specialty}
                              </span>
                            </div>
                          )}

                          {doctor.provider_professional_info.medical_school && (
                            <div className="flex items-center space-x-2">
                              <GraduationCap className="w-4 h-4 text-green-500" />
                              <span className="text-sm text-gray-600 truncate">
                                {doctor.provider_professional_info.medical_school}
                              </span>
                            </div>
                          )}

                          {doctor.current_practice_info.facility_name && (
                            <div className="flex items-center space-x-2">
                              <Building2 className="w-4 h-4 text-blue-500" />
                              <span className="text-sm text-gray-600 truncate">
                                {doctor.current_practice_info.facility_name}
                              </span>
                            </div>
                          )}

                          {displayAddress && (
                            <div className="flex items-center space-x-2">
                              <MapPin className="w-4 h-4 text-orange-500" />
                              <span className="text-sm text-gray-600">
                                {displayAddress.city}, {displayAddress.state}
                              </span>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>

                {/* Pagination */}
                <Pagination
                  currentPage={pagination.currentPage}
                  totalPages={pagination.totalPages}
                  onPageChange={handlePageChange}
                  className="mt-8"
                />
              </>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
