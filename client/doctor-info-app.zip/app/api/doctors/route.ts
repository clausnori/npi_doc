import { type NextRequest, NextResponse } from "next/server"
import { AbortSignal } from "abort-controller"

const API_BASE_URL = "http://127.0.0.1:8000"

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const page = searchParams.get("page") || "1"
  const limit = searchParams.get("limit") || "12"
  const search = searchParams.get("search") || ""
  const state = searchParams.get("state") || ""
  const city = searchParams.get("city") || ""

  let apiUrl = ""

  try {
    const params = new URLSearchParams({
      page,
      page_size: limit,
    })

    // Определяем какой endpoint использовать
    if (search) {
      // Поиск по имени
      params.append("search_term", search)
      apiUrl = `${API_BASE_URL}/providers/search/?${params}`
    } else if (state && city) {
      // Фильтрация по штату и городу
      params.append("state", state)
      params.append("city", city)
      apiUrl = `${API_BASE_URL}/providers/filter/?${params}`
    } else if (state) {
      // Провайдеры конкретного штата
      apiUrl = `${API_BASE_URL}/providers/by-state/${state}?${params}`
    } else {
      // Основной список провайдеров
      apiUrl = `${API_BASE_URL}/providers/?${params}`
    }

    console.log("Fetching from:", apiUrl)

    const response = await fetch(apiUrl, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      // Add timeout
      signal: AbortSignal.timeout(10000), // 10 second timeout
    })

    console.log("Response status:", response.status)
    console.log("Response headers:", Object.fromEntries(response.headers.entries()))

    if (!response.ok) {
      // Try to get error details
      let errorMessage = `API responded with status: ${response.status}`
      try {
        const errorText = await response.text()
        console.log("Error response body:", errorText)

        // Try to parse as JSON first
        try {
          const errorJson = JSON.parse(errorText)
          errorMessage = errorJson.message || errorJson.detail || errorMessage
        } catch {
          // If not JSON, use the text directly (but truncate if too long)
          if (errorText.length > 200) {
            errorMessage = `${errorMessage}. Response: ${errorText.substring(0, 200)}...`
          } else {
            errorMessage = `${errorMessage}. Response: ${errorText}`
          }
        }
      } catch (textError) {
        console.log("Could not read error response:", textError)
      }

      throw new Error(errorMessage)
    }

    // Get response text first
    const responseText = await response.text()
    console.log("Response body (first 500 chars):", responseText.substring(0, 500))

    // Try to parse as JSON
    let data
    try {
      data = JSON.parse(responseText)
    } catch (parseError) {
      console.error("JSON Parse Error:", parseError)
      console.log("Full response text:", responseText)
      throw new Error(`Invalid JSON response from API. Response was: ${responseText.substring(0, 200)}...`)
    }

    // Validate response structure
    if (!data || typeof data !== "object") {
      throw new Error("Invalid response structure from API")
    }

    // Адаптируем ответ под наш формат
    const adaptedResponse = {
      doctors: Array.isArray(data.data)
        ? data.data.map((item: any) => ({
            _id: item._id,
            ...item.provider,
          }))
        : [],
      pagination: {
        currentPage: data.pagination?.current_page || 1,
        totalPages: data.pagination?.total_pages || 1,
        totalDoctors: data.pagination?.total_items || 0,
        hasNextPage: data.pagination?.has_next || false,
        hasPrevPage: data.pagination?.has_previous || false,
        pageSize: data.pagination?.page_size || Number.parseInt(limit),
      },
    }

    console.log("Successfully processed response:", {
      doctorsCount: adaptedResponse.doctors.length,
      pagination: adaptedResponse.pagination,
    })

    return NextResponse.json(adaptedResponse)
  } catch (error) {
    console.error("API Error Details:", {
      message: error instanceof Error ? error.message : "Unknown error",
      stack: error instanceof Error ? error.stack : undefined,
      url: apiUrl,
    })

    // Return a more user-friendly error
    let userMessage = "Failed to fetch doctors data"
    if (error instanceof Error) {
      if (error.message.includes("fetch")) {
        userMessage =
          "Unable to connect to the API server. Please check if the server is running on http://127.0.0.1:8000"
      } else if (error.message.includes("timeout")) {
        userMessage = "Request timed out. The API server may be slow or unavailable."
      } else if (error.message.includes("Invalid JSON")) {
        userMessage = "The API server returned an invalid response. Please check the server logs."
      } else {
        userMessage = error.message
      }
    }

    return NextResponse.json(
      {
        error: "API_ERROR",
        message: userMessage,
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
