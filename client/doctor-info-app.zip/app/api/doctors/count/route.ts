import { NextResponse } from "next/server"

const API_BASE_URL = "http://127.0.0.1:8000"

export async function GET() {
  try {
    console.log("Fetching count from:", `${API_BASE_URL}/providers/count/`)

    const response = await fetch(`${API_BASE_URL}/providers/count/`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      signal: AbortSignal.timeout(5000), // 5 second timeout
    })

    console.log("Count response status:", response.status)

    if (!response.ok) {
      let errorMessage = `API responded with status: ${response.status}`
      try {
        const errorText = await response.text()
        console.log("Count error response:", errorText)
        try {
          const errorJson = JSON.parse(errorText)
          errorMessage = errorJson.message || errorJson.detail || errorMessage
        } catch {
          errorMessage = `${errorMessage}. Response: ${errorText.substring(0, 200)}`
        }
      } catch {
        // Ignore text reading errors
      }
      throw new Error(errorMessage)
    }

    const responseText = await response.text()
    console.log("Count response body:", responseText)

    let data
    try {
      data = JSON.parse(responseText)
    } catch (parseError) {
      console.error("Count JSON Parse Error:", parseError)
      throw new Error(`Invalid JSON response from count API: ${responseText.substring(0, 200)}`)
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error("Count API Error:", error)
    return NextResponse.json(
      {
        error: "COUNT_API_ERROR",
        message: error instanceof Error ? error.message : "Failed to fetch count data",
      },
      { status: 500 },
    )
  }
}
